function addToFavorites(title, url){
if (document.all)
window.external.AddFavorite(url, title);
else if (window.sidebar)
window.sidebar.addPanel(title, url, "")
}
 // Popup window function
 function newWindow(url) {
 popupWindow = window.open(url,'popUpWindow','height=600,width=600,left=50,top=50,resizable=yes,scrollbars=1,toolbar=no,menubar=no,location=no,directories=no,status=no');
	}
 function openInNewWindow(url, width, height, chrome)
{
	var features = "width=" + width + ",height=" + height;
	if (chrome)
	{
//		features += "menubar,location,resizable,status,toolbar";
		features += "resizable,scrollbars";
	}
	window.open(url, "", features);
}